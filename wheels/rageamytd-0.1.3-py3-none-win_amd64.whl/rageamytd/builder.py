from __future__ import annotations

from ctypes import c_float, c_int, c_void_p, c_wchar_p
from pathlib import Path
from typing import Iterable, Optional, Sequence

from .images import scan_images
from .native import get_native
from .options import Compression, EncodingOptions, MipMapOptions


class YTDBuilder:
    """
    Programmatic YTD builder (write-only).

    Concepts:
    - Inputs: image file paths (dds/png/jpg/...)
    - EncodingOptions: compression/mips/etc
    - Output: a compiled .ytd file
    """

    def __init__(self, *, options: EncodingOptions | None = None, dll_path: Optional[str | Path] = None):
        self._n = get_native(dll_path)
        h = self._n.lib.rageamytd_ytd_create()
        self._h = c_void_p(h)
        if not self._h.value:
            raise RuntimeError(self._n.last_error() or "Failed to create YTD handle.")

        self._options = options or EncodingOptions()
        self.apply_options(self._options)

    def close(self) -> None:
        if self._h.value:
            self._n.lib.rageamytd_ytd_destroy(self._h)
            self._h = c_void_p()

    def __del__(self) -> None:  # best-effort
        try:
            self.close()
        except Exception:
            pass

    @staticmethod
    def supported_extensions(*, dll_path: Optional[str | Path] = None) -> list[str]:
        n = get_native(dll_path)
        raw = n.supported_extensions_raw()
        return [e for e in raw.split(";") if e]

    @property
    def options(self) -> EncodingOptions:
        return self._options

    def apply_options(self, options: EncodingOptions) -> None:
        """
        Apply options to the native builder handle.
        """
        self._set_quality(options.quality)
        self._set_compression(options.compression)
        self._set_mipmaps(options.mipmaps)
        self._set_pad_to_power_of_two(options.pad_to_power_of_two)
        self._options = options

    def _err(self, fallback: str) -> RuntimeError:
        return RuntimeError(self._n.last_error() or fallback)

    def _set_quality(self, quality_0_1: float) -> None:
        ok = self._n.lib.rageamytd_ytd_set_quality(self._h, c_float(quality_0_1))
        if not ok:
            raise self._err("set_quality failed.")

    def _set_compression(self, compression: Compression) -> None:
        ok = self._n.lib.rageamytd_ytd_set_compression(self._h, c_int(int(compression)))
        if not ok:
            raise self._err("set_compression failed.")

    def _set_mipmaps(self, mipmaps: MipMapOptions) -> None:
        ok = self._n.lib.rageamytd_ytd_set_generate_mips(self._h, c_int(1 if mipmaps.generate else 0))
        if not ok:
            raise self._err("set_generate_mips failed.")

        ok = self._n.lib.rageamytd_ytd_set_min_mip_dimension(self._h, c_int(int(mipmaps.min_dimension)))
        if not ok:
            raise self._err("set_min_mip_dimension failed.")

    def _set_pad_to_power_of_two(self, enable: bool) -> None:
        ok = self._n.lib.rageamytd_ytd_set_pad_to_power_of_two(self._h, c_int(1 if enable else 0))
        if not ok:
            raise self._err("set_pad_to_power_of_two failed.")

    def clear(self) -> None:
        self._n.lib.rageamytd_ytd_clear(self._h)

    def add(self, path: str | Path, *, options: EncodingOptions | None = None) -> None:
        p = str(Path(path))
        if options is None:
            ok = self._n.lib.rageamytd_ytd_add_image(self._h, c_wchar_p(p))
        else:
            ok = self._n.lib.rageamytd_ytd_add_image_ex(
                self._h,
                c_wchar_p(p),
                c_int(int(options.compression)),
                c_float(float(options.quality)),
                c_int(1 if options.mipmaps.generate else 0),
                c_int(int(options.mipmaps.min_dimension)),
                c_int(1 if options.pad_to_power_of_two else 0),
            )
        if not ok:
            raise self._err(f"add failed: {p}")

    def add_many(self, paths: Iterable[str | Path]) -> None:
        for p in paths:
            self.add(p)

    def add_with_options(self, path: str | Path, options: EncodingOptions) -> None:
        """
        Add a single image with per-image encoding overrides.
        Equivalent to: add(path, options=options)
        """
        self.add(path, options=options)

    def add_dir(
        self,
        directory: str | Path,
        *,
        recursive: bool = False,
        extensions: Optional[Sequence[str]] = None,
        use_supported_extensions: bool = True,
    ) -> int:
        """
        Import files from a folder. Returns number of added files.

        If extensions is None and use_supported_extensions is True, uses the DLL-reported extensions.
        """
        exts: Optional[Sequence[str]]
        if extensions is None and use_supported_extensions:
            exts = self.supported_extensions()
        else:
            exts = extensions

        files = scan_images(directory, recursive=recursive, extensions=exts)
        self.add_many(files)
        return len(files)

    def save(self, out_ytd: str | Path) -> None:
        p = str(Path(out_ytd))
        ok = self._n.lib.rageamytd_ytd_save(self._h, c_wchar_p(p))
        if not ok:
            raise self._err(f"save failed: {p}")


# Back-compat alias (deprecated). Kept to avoid breaking earlier snippets.
class YTDFile(YTDBuilder):
    pass
