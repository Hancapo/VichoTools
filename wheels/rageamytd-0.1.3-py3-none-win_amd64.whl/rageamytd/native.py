from __future__ import annotations

from ctypes import WinDLL, c_int, c_float, c_void_p, c_wchar_p
from pathlib import Path
from typing import Optional


class NativeLib:
    """
    Thin ctypes binding over rageamytd.dll.

    Keep this low-level: no path scanning, no options policy, no convenience helpers.
    """

    def __init__(self, dll_path: Path):
        self.dll_path = dll_path
        self.lib = WinDLL(str(dll_path))

        self.lib.rageamytd_last_error.restype = c_wchar_p
        self.lib.rageamytd_supported_extensions.restype = c_wchar_p

        self.lib.rageamytd_ytd_create.restype = c_void_p

        self.lib.rageamytd_ytd_destroy.argtypes = [c_void_p]
        self.lib.rageamytd_ytd_destroy.restype = None

        self.lib.rageamytd_ytd_clear.argtypes = [c_void_p]
        self.lib.rageamytd_ytd_clear.restype = None

        self.lib.rageamytd_ytd_set_quality.argtypes = [c_void_p, c_float]
        self.lib.rageamytd_ytd_set_quality.restype = c_int

        self.lib.rageamytd_ytd_set_compression.argtypes = [c_void_p, c_int]
        self.lib.rageamytd_ytd_set_compression.restype = c_int

        self.lib.rageamytd_ytd_set_generate_mips.argtypes = [c_void_p, c_int]
        self.lib.rageamytd_ytd_set_generate_mips.restype = c_int

        self.lib.rageamytd_ytd_set_min_mip_dimension.argtypes = [c_void_p, c_int]
        self.lib.rageamytd_ytd_set_min_mip_dimension.restype = c_int

        self.lib.rageamytd_ytd_set_pad_to_power_of_two.argtypes = [c_void_p, c_int]
        self.lib.rageamytd_ytd_set_pad_to_power_of_two.restype = c_int

        self.lib.rageamytd_ytd_add_image.argtypes = [c_void_p, c_wchar_p]
        self.lib.rageamytd_ytd_add_image.restype = c_int

        self.lib.rageamytd_ytd_add_image_ex.argtypes = [
            c_void_p,
            c_wchar_p,
            c_int,   # compression_kind
            c_float, # quality_0_1
            c_int,   # generate_mips
            c_int,   # min_mip_dimension
            c_int,   # pad_to_power_of_two
        ]
        self.lib.rageamytd_ytd_add_image_ex.restype = c_int

        self.lib.rageamytd_ytd_save.argtypes = [c_void_p, c_wchar_p]
        self.lib.rageamytd_ytd_save.restype = c_int

    def last_error(self) -> str:
        msg = self.lib.rageamytd_last_error()
        return msg or ""

    def supported_extensions_raw(self) -> str:
        msg = self.lib.rageamytd_supported_extensions()
        return msg or ""


def default_dll_path() -> Path:
    # 1) Prefer DLL shipped inside the installed wheel/package:
    #    python/rageamytd/_bin/rageamytd.dll
    pkg = Path(__file__).resolve().parent
    packaged = pkg / "_bin" / "rageamytd.dll"
    if packaged.is_file():
        return packaged

    # 2) Dev fallback: repo_root/bin/{Release,Debug}/rageamytd.dll
    repo_root = pkg.parents[1]
    candidates = [
        repo_root / "bin" / "Release" / "rageamytd.dll",
        repo_root / "bin" / "Debug" / "rageamytd.dll",
    ]
    for p in candidates:
        if p.is_file():
            return p
    raise FileNotFoundError(
        "Couldn't find rageamytd.dll. Build the `rageamytd` project (bin/Release/rageamytd.dll)."
    )


_native_singleton: Optional[NativeLib] = None


def get_native(dll_path: Optional[str | Path] = None) -> NativeLib:
    """
    Loads and returns the native DLL binding.
    If dll_path is omitted, uses repo-local bin/Release or bin/Debug and caches the instance.
    """
    global _native_singleton

    if dll_path is None:
        if _native_singleton is None:
            _native_singleton = NativeLib(default_dll_path())
        return _native_singleton

    p = Path(dll_path)
    if not p.is_file():
        raise FileNotFoundError(str(p))
    return NativeLib(p)
