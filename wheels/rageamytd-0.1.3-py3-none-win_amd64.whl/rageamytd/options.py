from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum


class Compression(IntEnum):
    """
    Compression formats exposed by the native DLL.
    """

    RAW_RGBA = 0
    DXT1 = 1  # BC1
    DXT5 = 2  # BC3
    BC5 = 3
    BC7 = 4


@dataclass(frozen=True)
class MipMapOptions:
    """
    Mipmap generation policy.

    min_dimension semantics: stop generating when either side reaches this size.
    For block-compressed formats, the native side clamps to >= 4.
    """

    generate: bool = True
    min_dimension: int = 4


@dataclass(frozen=True)
class EncodingOptions:
    """
    How images are encoded into the final YTD.
    """

    compression: Compression = Compression.BC7
    quality: float = 0.65  # 0..1
    pad_to_power_of_two: bool = False
    mipmaps: MipMapOptions = field(default_factory=MipMapOptions)

