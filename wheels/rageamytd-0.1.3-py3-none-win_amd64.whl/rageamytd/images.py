from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional, Sequence


def normalize_extensions(exts: Iterable[str]) -> set[str]:
    return {e.lower().lstrip(".") for e in exts if e}


def scan_images(
    directory: str | Path,
    *,
    recursive: bool = False,
    extensions: Optional[Sequence[str]] = None,
) -> list[Path]:
    """
    Return a deterministic list of files to import from a directory.
    """
    d = Path(directory)
    if not d.is_dir():
        raise NotADirectoryError(str(d))

    ext_set = normalize_extensions(extensions or [])

    it = d.rglob("*") if recursive else d.glob("*")
    out: list[Path] = []
    for p in it:
        if not p.is_file():
            continue
        if ext_set:
            ext = p.suffix.lower().lstrip(".")
            if ext not in ext_set:
                continue
        out.append(p)

    # deterministic ordering
    out.sort(key=lambda x: str(x).lower())
    return out

