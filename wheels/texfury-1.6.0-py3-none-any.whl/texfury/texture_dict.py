"""Internal Texture Dictionary (ITD) — unified texture dictionary handling for RAGE games."""

from __future__ import annotations

import logging
import struct
from enum import Enum
from pathlib import Path
from typing import Callable

log = logging.getLogger("texfury")

from texfury.formats import (
    BCFormat, MipFilter, RscCompression,
    BC_TO_DX9, DX9_TO_BC, FOURCC_TO_BC, DXGI_TO_BC,
    BC_TO_RSC8, RSC8_TO_BC,
    BC_TO_RSC5, RSC5_TO_BC, _GTA4_UNSUPPORTED,
    row_pitch, total_mip_data_size, mip_data_size, is_block_compressed,
)
from texfury.rsc import (
    DAT_VIRTUAL_BASE, DAT_PHYSICAL_BASE,
    RSC5_MAGIC, build_rsc5, decompress_rsc5,
    RSC7_MAGIC, build_rsc7, decompress_rsc7, parse_rsc7_header,
    RSC8_MAGIC, build_rsc8, decompress_rsc8,
)
from texfury.binary import r_u8, r_u16, r_i16, r_u32, r_u64, align, joaat
from texfury.texture import Texture


# ── Game enum ────────────────────────────────────────────────────────────────

class Game(str, Enum):
    """Target game / edition for texture dictionaries."""
    GTA4 = "gta4"
    GTA5 = "gta5"
    GTA5_GEN9 = "gta5_enhanced"
    RDR2 = "rdr2"


# ── Shared helpers ───────────────────────────────────────────────────────────

def v2o(addr: int) -> int: return addr - DAT_VIRTUAL_BASE
def p2o(addr: int) -> int: return addr - DAT_PHYSICAL_BASE


def _slice_texture_data(physical_data: bytes, phys_off: int, data_size: int,
                        *, name: str, width: int, height: int,
                        mip_levels: int) -> bytes:
    if width <= 0 or height <= 0:
        raise ValueError(f"Invalid dimensions for '{name}': {width}x{height}")
    if mip_levels < 1:
        raise ValueError(f"Invalid mip count for '{name}': {mip_levels}")
    if phys_off < 0 or data_size < 0 or phys_off + data_size > len(physical_data):
        raise ValueError(
            f"Texture data for '{name}' is outside the physical buffer "
            f"(offset={phys_off}, size={data_size}, buffer={len(physical_data)})"
        )
    return physical_data[phys_off:phys_off + data_size]


def _detect_game(file_data: bytes) -> Game:
    """Detect game from the RSC magic bytes and version."""
    if len(file_data) < 12:
        raise ValueError("File too short to detect format")
    magic = struct.unpack_from("<I", file_data, 0)[0]
    if magic == RSC5_MAGIC:
        return Game.GTA4
    if magic == RSC7_MAGIC:
        version = struct.unpack_from("<I", file_data, 4)[0]
        if version == 5:
            return Game.GTA5_GEN9
        return Game.GTA5
    if magic == RSC8_MAGIC:
        return Game.RDR2
    raise ValueError(f"Unknown texture dictionary format — magic: 0x{magic:08X}")


def _build_mip_info(
    width: int, height: int, fmt: BCFormat, mip_count: int,
) -> tuple[list[int], list[int]]:
    """Build mip offset/size lists. Shared by both games."""
    offsets, sizes = [], []
    w, h, off = width, height, 0
    for _ in range(mip_count):
        ms = mip_data_size(w, h, fmt)
        offsets.append(off)
        sizes.append(ms)
        off += ms
        w = max(1, w // 2)
        h = max(1, h // 2)
    return offsets, sizes


def _read_name(virtual_data: bytes, name_ptr: int) -> str:
    name_off = v2o(name_ptr)
    name_end = virtual_data.index(b"\x00", name_off)
    return virtual_data[name_off:name_end].decode("utf-8", errors="replace")


def _block_stride(fmt: BCFormat) -> int:
    """Block stride in bytes. Used by RDR2 and GTA V Enhanced."""
    if fmt in (BCFormat.BC1, BCFormat.BC1A, BCFormat.BC4):
        return 8
    if fmt in (BCFormat.BC3, BCFormat.BC5, BCFormat.BC7):
        return 16
    return 4  # A8R8G8B8 / uncompressed


def _block_count(fmt: BCFormat, w: int, h: int, depth: int, mips: int,
                 *, align: int | None = None) -> int:
    """Total block count across all mip levels.

    Parameters
    ----------
    align : int or None
        Block alignment per axis.  ``None`` (default) uses RDR2-style
        alignment (16 for stride==1, else 8).  Pass ``1`` for GTA V
        Enhanced which has no alignment padding.
    """
    bs = _block_stride(fmt)
    bp = 4 if is_block_compressed(fmt) else 1

    bw, bh = w, h
    if mips > 1:
        bw = 1
        while bw < w:
            bw *= 2
        bh = 1
        while bh < h:
            bh *= 2

    if align is None:
        align = 16 if bs == 1 else 8
    bc = 0
    for _ in range(mips):
        bx = max(1, (bw + bp - 1) // bp)
        by = max(1, (bh + bp - 1) // bp)
        bx += (align - (bx % align)) % align
        by += (align - (by % align)) % align
        bc += bx * by * depth
        bw //= 2
        bh //= 2

    return bc


IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tga", ".tiff",
                    ".tif", ".webp", ".psd", ".gif", ".hdr"}


# ── ITD ──────────────────────────────────────────────────────────────────

class ITD:
    """Internal Texture Dictionary — generic abstraction over RAGE texture
    dictionary formats (.wtd for x32, .ytd for x64).

    Usage:
        td = ITD()                          # GTA V Legacy by default
        td = ITD(game=Game.GTA4)            # GTA IV (.wtd)
        td = ITD(game=Game.GTA5_GEN9)   # GTA V Enhanced
        td = ITD(game=Game.RDR2)            # RDR2

        td.add(Texture.from_image("logo.png"))
        td.save("output.ytd")

        td = ITD.load("existing.ytd")       # auto-detects game
    """

    __slots__ = ("_textures", "_game")

    def __init__(self, game: Game = Game.GTA5) -> None:
        self._textures: list[Texture] = []
        self._game: Game = game

    # ── Properties ──────────────────────────────────────────────────────

    @property
    def game(self) -> Game:
        return self._game

    @property
    def textures(self) -> list[Texture]:
        return list(self._textures)

    # ── Mutation ────────────────────────────────────────────────────────

    def add(self, texture: Texture) -> None:
        """Add a texture to the dictionary."""
        if not texture.name:
            raise ValueError("Texture must have a name before adding to a dictionary")
        log.debug("add: %s (%s %dx%d)", texture.name, texture.format.name, texture.width, texture.height)
        self._textures.append(texture)

    def replace(self, name: str, texture: Texture) -> None:
        """Replace a texture by name. Raises KeyError if not found."""
        lower = name.lower()
        for i, t in enumerate(self._textures):
            if t.name.lower() == lower:
                if texture.name != t.name:
                    texture.name = t.name
                self._textures[i] = texture
                return
        raise KeyError(f"Texture '{name}' not found in dictionary")

    def remove(self, name: str) -> None:
        """Remove a texture by name. Raises KeyError if not found."""
        lower = name.lower()
        for i, t in enumerate(self._textures):
            if t.name.lower() == lower:
                self._textures.pop(i)
                return
        raise KeyError(f"Texture '{name}' not found in dictionary")

    def merge(self, other: ITD, *, overwrite: bool = False) -> None:
        """Merge textures from another dictionary into this one.

        Parameters
        ----------
        other : ITD
            Source dictionary to merge from.
        overwrite : bool
            If True, textures with duplicate names are replaced.
            If False (default), duplicates are skipped.
        """
        existing = {t.name.lower() for t in self._textures}
        for tex in other.textures:
            lower = tex.name.lower()
            if lower in existing:
                if overwrite:
                    self.replace(tex.name, tex)
                    log.debug("merge: replaced %s", tex.name)
                else:
                    log.debug("merge: skipped duplicate %s", tex.name)
                continue
            self._textures.append(tex)
            existing.add(lower)
            log.debug("merge: added %s", tex.name)

    @staticmethod
    def merge_many(
        paths: list[str | Path],
        *,
        game: Game | None = None,
        overwrite: bool = False,
    ) -> ITD:
        """Load and merge multiple texture dictionaries into one.

        Parameters
        ----------
        paths : list of str or Path
            Paths to texture dictionaries to merge.
        game : Game, optional
            Target game format. If None, uses the game of the first file.
        overwrite : bool
            If True, later files overwrite earlier duplicates.
            If False (default), first occurrence wins.
        """
        if not paths:
            raise ValueError("paths must not be empty")
        result = ITD.load(paths[0])
        if game is not None:
            result._game = game
        log.info("merge_many: starting with %s (%d textures)", paths[0], len(result))
        for p in paths[1:]:
            other = ITD.load(p)
            result.merge(other, overwrite=overwrite)
            log.info("merge_many: merged %s (%d textures)", p, len(other))
        return result

    # ── Lookup ──────────────────────────────────────────────────────────

    def get(self, name: str) -> Texture:
        """Get a texture by name. Raises KeyError if not found."""
        lower = name.lower()
        for t in self._textures:
            if t.name.lower() == lower:
                return t
        raise KeyError(f"Texture '{name}' not found in dictionary")

    def names(self) -> list[str]:
        """Return the names of all textures."""
        return [t.name for t in self._textures]

    # ── I/O ─────────────────────────────────────────────────────────────

    def save(self, path: str | Path, *,
             compression: RscCompression | None = None) -> None:
        """Build and write the texture dictionary to a file.

        *compression* only applies to RDR2 (RSC8).  Defaults to
        :attr:`RscCompression.OODLE` for RDR2 and is ignored for other games.
        """
        log.info("save: %s (%s, %d textures)", path, self._game.value, len(self._textures))
        if self._game == Game.RDR2:
            if compression is None:
                compression = RscCompression.OODLE
            data = _build_rdr2(self._textures, compression=compression)
        else:
            builders = {
                Game.GTA4: _build_gta4,
                Game.GTA5: _build_gtav,
                Game.GTA5_GEN9: _build_enhanced,
            }
            data = builders[self._game](self._textures)
        Path(path).write_bytes(data)
        log.info("save: wrote %d bytes", len(data))

    @staticmethod
    def load(path: str | Path) -> ITD:
        """Read a texture dictionary — auto-detects game from header."""
        log.info("load: %s", path)
        file_data = Path(path).read_bytes()
        game = _detect_game(file_data)
        log.debug("load: detected game=%s, %d bytes", game.value, len(file_data))
        parsers = {
            Game.GTA4: _parse_gta4,
            Game.GTA5: _parse_gtav,
            Game.GTA5_GEN9: _parse_enhanced,
            Game.RDR2: _parse_rdr2,
        }
        return parsers[game](file_data)

    @classmethod
    def from_folder(
        cls,
        folder: str | Path,
        *,
        game: Game = Game.GTA5,
        format: BCFormat = BCFormat.BC7,
        quality: float = 0.7,
        generate_mipmaps: bool = True,
        min_mip_size: int = 4,
        mip_filter: MipFilter = MipFilter.MITCHELL,
        on_progress: Callable[[int, int, str], None] | None = None,
    ) -> ITD:
        """Build a texture dictionary from all images in a folder.

        Returns the populated ITD without writing to disk.
        Call ``.save(path)`` afterwards to write the file.
        """
        folder = Path(folder)
        if not folder.is_dir():
            raise FileNotFoundError(f"Not a directory: {folder}")

        files = sorted(
            f for f in folder.iterdir()
            if f.suffix.lower() in IMAGE_EXTENSIONS or f.suffix.lower() == ".dds"
        )
        if not files:
            raise FileNotFoundError(f"No image files found in {folder}")

        td = cls(game=game)
        total = len(files)
        for i, f in enumerate(files):
            name = f.stem.lower()
            if on_progress:
                on_progress(i + 1, total, name)
            if f.suffix.lower() == ".dds":
                tex = Texture.from_dds(f, name=name)
            else:
                tex = Texture.from_image(f, format=format, quality=quality,
                                         generate_mipmaps=generate_mipmaps,
                                         min_mip_size=min_mip_size,
                                         mip_filter=mip_filter, name=name)
            td.add(tex)
        return td

    def extract(self, output_dir: str | Path) -> Path:
        """Extract all textures to DDS files in the given directory.

        Returns the output directory path.
        """
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        for tex in self._textures:
            tex.save_dds(out / f"{tex.name}.dds")
        return out

    @staticmethod
    def inspect(path: str | Path) -> list[dict]:
        """Read texture metadata without loading pixel data. Auto-detects game."""
        file_data = Path(path).read_bytes()
        game = _detect_game(file_data)
        inspectors = {
            Game.GTA4: _inspect_gta4,
            Game.GTA5: _inspect_gtav,
            Game.GTA5_GEN9: _inspect_enhanced,
            Game.RDR2: _inspect_rdr2,
        }
        return inspectors[game](file_data)

    # ── Fix / optimize ───────────────────────────────────────────────

    def fix_textures(
        self,
        *,
        quality: float = 0.7,
        min_mip_size: int = 4,
        mip_filter: MipFilter = MipFilter.MITCHELL,
        ignore: set[str] | list[str] | None = None,
        on_progress: Callable[[int, int, str], None] | None = None,
    ) -> list[dict]:
        """Fix common texture issues in-place.

        For each texture, checks and corrects:
        - **Non-power-of-two** dimensions → resized to nearest POT.
        - **Missing mipmaps** → regenerated (expected mips for ≥8×8 textures).
        - **Format choice** → BC1 for opaque textures, BC3 for transparent
          (only if current format is a BC type that doesn't match).

        Returns a list of dicts describing what was fixed, one per
        texture that was modified.  Unmodified textures are omitted.

        Parameters
        ----------
        quality : float
            Compression quality for recompressed textures.
        min_mip_size : int
            Minimum dimension for the smallest mip level.
        mip_filter : MipFilter
            Downsampling filter for mipmap generation and POT resize.
        ignore : set or list of str, optional
            Texture names to skip.  These textures will not be
            inspected or modified.
        on_progress : callable, optional
            ``(current, total, texture_name)`` callback.
        """
        from texfury import _native as native

        report: list[dict] = []
        total = len(self._textures)
        skip = set(ignore) if ignore else set()

        for idx, tex in enumerate(self._textures):
            if on_progress:
                on_progress(idx + 1, total, tex.name)

            if tex.name in skip:
                continue

            fixes: list[str] = []

            # Determine expected mip count
            w, h = tex.width, tex.height
            expected_mips = 1
            dim = max(w, h)
            while dim > min_mip_size:
                dim //= 2
                expected_mips += 1

            needs_pot = not tex.is_power_of_two
            needs_mips = tex.mip_count < expected_mips and max(w, h) >= 8

            # Only suggest format change for BC formats
            needs_format = False
            suggested_fmt = tex.format
            if is_block_compressed(tex.format):
                transparent = tex.has_transparency()
                if transparent and tex.format == BCFormat.BC1:
                    suggested_fmt = BCFormat.BC3
                    needs_format = True
                    fixes.append(f"format BC1→BC3 (has transparency)")
                elif not transparent and tex.format in (
                    BCFormat.BC1A, BCFormat.BC3, BCFormat.BC7,
                ):
                    suggested_fmt = BCFormat.BC1
                    needs_format = True
                    fixes.append(f"format {tex.format.name}→BC1 (opaque)")

            if needs_pot:
                fixes.append("resize to power-of-two")
            if needs_mips:
                fixes.append(f"mipmaps {tex.mip_count}→{expected_mips}")

            if not fixes:
                continue

            # Decompress → recompress with fixes
            rgba, rw, rh = tex.to_rgba(0)
            img = native.create_image(rw, rh, rgba)
            try:
                new_tex = Texture._compress_image(
                    img,
                    format=suggested_fmt,
                    quality=quality,
                    generate_mipmaps=True,
                    min_mip_size=min_mip_size,
                    resize_to_pot=True,
                    mip_filter=mip_filter,
                    name=tex.name,
                )
            finally:
                native.free_image(img)

            self._textures[idx] = new_tex
            log.info("fix_textures: %s → %s", tex.name, ", ".join(fixes))
            report.append({"name": tex.name, "fixes": fixes})

        return report

    def convert(
        self,
        game: Game,
        *,
        quality: float = 0.7,
        generate_mipmaps: bool = True,
        min_mip_size: int = 4,
        mip_filter: MipFilter = MipFilter.MITCHELL,
    ) -> list[dict]:
        """Convert this dictionary to a different game format in-place.

        Textures using formats unsupported by the target game are
        recompressed automatically (e.g. BC7 → BC1 for GTA IV).

        Parameters
        ----------
        game : Game
            Target game format.
        quality : float
            Compression quality for recompressed textures.
        generate_mipmaps : bool
            Regenerate mipmaps for recompressed textures.
        min_mip_size : int
            Minimum dimension for the smallest mip level.
        mip_filter : MipFilter
            Downsampling filter for mipmap generation.

        Returns
        -------
        list of dict
            One entry per recompressed texture: ``{"name": str, "old_format": str, "new_format": str}``.
        """
        from texfury import _native as native

        log.info("convert: %s → %s", self._game.value, game.value)
        self._game = game

        if game != Game.GTA4:
            return []

        report: list[dict] = []
        for idx, tex in enumerate(self._textures):
            if tex.format not in _GTA4_UNSUPPORTED:
                continue

            # Pick replacement format
            old_name = tex.format.name
            if tex.format in (BCFormat.BC4, BCFormat.BC5, BCFormat.BC6H):
                new_fmt = BCFormat.BC1
            elif tex.format == BCFormat.BC7:
                transparent = tex.has_transparency()
                new_fmt = BCFormat.BC3 if transparent else BCFormat.BC1
            else:
                # Uncompressed formats not supported by GTA4 → A8R8G8B8
                new_fmt = BCFormat.A8R8G8B8

            log.info("convert: %s %s → %s", tex.name, old_name, new_fmt.name)
            rgba, w, h = tex.to_rgba(0)
            img = native.create_image(w, h, rgba)
            try:
                new_tex = Texture._compress_image(
                    img,
                    format=new_fmt,
                    quality=quality,
                    generate_mipmaps=generate_mipmaps,
                    min_mip_size=min_mip_size,
                    resize_to_pot=True,
                    mip_filter=mip_filter,
                    name=tex.name,
                )
            finally:
                native.free_image(img)

            self._textures[idx] = new_tex
            report.append({"name": tex.name, "old_format": old_name, "new_format": new_fmt.name})

        return report

    # ── Dunder ──────────────────────────────────────────────────────────

    def __len__(self) -> int:
        return len(self._textures)

    def __iter__(self):
        return iter(self._textures)

    def __getitem__(self, name: str) -> Texture:
        """Lookup by name: ``td["body_d"]``."""
        return self.get(name)

    def __contains__(self, name: str) -> bool:
        lower = name.lower()
        return any(t.name.lower() == lower for t in self._textures)

    def __repr__(self) -> str:
        count = len(self._textures)
        summary = ", ".join(t.name for t in self._textures[:5])
        if count > 5:
            summary += f", ... (+{count - 5} more)"
        return f"ITD(game={self._game.value!r}, textures={count}, [{summary}])"


# ── Convenience functions ────────────────────────────────────────────────────

def create_dict_from_folder(
    folder: str | Path,
    output: str | Path | None = None,
    *,
    game: Game = Game.GTA5,
    format: BCFormat = BCFormat.BC1,
    quality: float = 0.7,
    generate_mipmaps: bool = True,
    min_mip_size: int = 4,
    mip_filter: MipFilter = MipFilter.MITCHELL,
    compression: RscCompression | None = None,
    on_progress: Callable[[int, int, str], None] | None = None,
) -> ITD:
    """Create a texture dictionary from all images in a folder.

    If *output* is given the dictionary is saved to disk immediately.
    Otherwise it is only built in memory — call ``td.save(path)`` later.

    *compression* only applies to RDR2 (RSC8).  Defaults to
    :attr:`RscCompression.OODLE` for RDR2 and is ignored for other games.

    Returns the populated :class:`ITD`.
    """
    td = ITD.from_folder(
        folder, game=game, format=format, quality=quality,
        generate_mipmaps=generate_mipmaps, min_mip_size=min_mip_size,
        mip_filter=mip_filter, on_progress=on_progress,
    )
    if output is not None:
        td.save(output, compression=compression)
    return td


def batch_convert(
    folder: str | Path,
    output_dir: str | Path | None = None,
    *,
    format: BCFormat = BCFormat.BC1,
    quality: float = 0.7,
    generate_mipmaps: bool = True,
    min_mip_size: int = 4,
    mip_filter: MipFilter = MipFilter.MITCHELL,
    on_progress: Callable[[int, int, str], None] | None = None,
) -> Path:
    """Convert all images in a folder to DDS files."""
    folder = Path(folder)
    if not folder.is_dir():
        raise FileNotFoundError(f"Not a directory: {folder}")

    if output_dir is None:
        output_dir = folder / "dds_out"
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    files = sorted(
        f for f in folder.iterdir()
        if f.suffix.lower() in IMAGE_EXTENSIONS
    )
    if not files:
        raise FileNotFoundError(f"No image files found in {folder}")

    total = len(files)
    for i, f in enumerate(files):
        name = f.stem.lower()
        if on_progress:
            on_progress(i + 1, total, name)

        tex = Texture.from_image(f, format=format, quality=quality,
                                 generate_mipmaps=generate_mipmaps,
                                 min_mip_size=min_mip_size,
                                 mip_filter=mip_filter, name=name)
        tex.save_dds(output_dir / f"{name}.dds")

    return output_dir


def extract_dict(
    source: ITD | str | Path,
    output_dir: str | Path | None = None,
) -> Path:
    """Extract all textures as DDS files.

    *source* can be an already-loaded :class:`ITD` or a file path (auto-detects game).
    If *output_dir* is omitted, a folder named after the file stem is created
    next to it (or ``extracted/`` when *source* is an ITD).

    Returns the output directory path.
    """
    if isinstance(source, ITD):
        td = source
        if output_dir is None:
            output_dir = Path("extracted")
    else:
        source = Path(source)
        td = ITD.load(source)
        if output_dir is None:
            output_dir = source.parent / source.stem

    return td.extract(output_dir)


# ═════════════════════════════════════════════════════════════════════════════
# GTA V (RSC7) internals
# ═════════════════════════════════════════════════════════════════════════════

_GTAV_TEX_SIZE = 0x90  # 144 bytes


def _resolve_gtav_format(format_val: int) -> BCFormat | None:
    if format_val in DX9_TO_BC:
        return DX9_TO_BC[format_val]
    if format_val in FOURCC_TO_BC:
        return FOURCC_TO_BC[format_val]
    if format_val in DXGI_TO_BC:
        return DXGI_TO_BC[format_val]
    return None


def _large_mip_data_size(w: int, h: int, fmt: BCFormat, levels: int) -> int:
    total = 0
    for lvl in range(levels):
        mw = max(1, w >> lvl)
        mh = max(1, h >> lvl)
        if mw >= 16 and mh >= 16:
            total += mip_data_size(mw, mh, fmt)
    return total


def _build_gtav(textures: list[Texture]) -> bytes:
    entries = sorted(textures, key=lambda t: joaat(t.name))
    n = len(entries)
    if n == 0:
        raise ValueError("Cannot create texture dictionary with zero textures")

    # Virtual layout
    dict_size = 0x40
    keys_offset = dict_size
    ptrs_offset = align(keys_offset + 4 * n, 16)
    textures_offset = align(ptrs_offset + 8 * n, 16)

    cur = textures_offset + _GTAV_TEX_SIZE * n
    name_offsets: list[int] = []
    name_bytes_list: list[bytes] = []
    for e in entries:
        name_offsets.append(cur)
        encoded = e.name.encode("utf-8") + b"\x00"
        name_bytes_list.append(encoded)
        cur += len(encoded)

    pagemap_offset = align(cur, 16)
    virtual_size = pagemap_offset + 0x10

    # Physical layout
    phys_offsets: list[int] = []
    phys_cur = 0
    for e in entries:
        phys_offsets.append(phys_cur)
        phys_cur += len(e.data)

    # Build virtual buffer
    vbuf = bytearray(virtual_size)

    struct.pack_into("<Q", vbuf, 0x00, 0)
    struct.pack_into("<Q", vbuf, 0x08, DAT_VIRTUAL_BASE + pagemap_offset)
    struct.pack_into("<Q", vbuf, 0x10, 0)
    struct.pack_into("<I", vbuf, 0x18, 1)
    struct.pack_into("<I", vbuf, 0x1C, 0)
    struct.pack_into("<Q", vbuf, 0x20, DAT_VIRTUAL_BASE + keys_offset)
    struct.pack_into("<HHI", vbuf, 0x28, n, n, 0)
    struct.pack_into("<Q", vbuf, 0x30, DAT_VIRTUAL_BASE + ptrs_offset)
    struct.pack_into("<HHI", vbuf, 0x38, n, n, 0)

    for i, e in enumerate(entries):
        struct.pack_into("<I", vbuf, keys_offset + 4 * i, joaat(e.name))

    for i in range(n):
        tex_vaddr = DAT_VIRTUAL_BASE + textures_offset + _GTAV_TEX_SIZE * i
        struct.pack_into("<Q", vbuf, ptrs_offset + 8 * i, tex_vaddr)

    for i, e in enumerate(entries):
        off = textures_offset + _GTAV_TEX_SIZE * i
        format_val = BC_TO_DX9[e.format]
        stride = row_pitch(e.width, e.format)
        name_vaddr = DAT_VIRTUAL_BASE + name_offsets[i]
        data_paddr = DAT_PHYSICAL_BASE + phys_offsets[i]
        data_size_large = _large_mip_data_size(e.width, e.height, e.format, e.mip_count)

        struct.pack_into("<Q", vbuf, off + 0x00, 0)
        struct.pack_into("<q", vbuf, off + 0x08, 0)
        struct.pack_into("<q", vbuf, off + 0x10, 0)
        struct.pack_into("<Q", vbuf, off + 0x18, 0)
        struct.pack_into("<Q", vbuf, off + 0x20, 0)
        struct.pack_into("<Q", vbuf, off + 0x28, name_vaddr)
        struct.pack_into("<hbbiQ", vbuf, off + 0x30, 1, 0, 0, 0, 0)
        struct.pack_into("<I", vbuf, off + 0x40, data_size_large)
        struct.pack_into("<iihhhhI", vbuf, off + 0x44, 0, 0, 0, 0, e.width, e.height, 0)
        struct.pack_into("<hI", vbuf, off + 0x54, 1, 0)
        struct.pack_into("<h", vbuf, off + 0x56, stride)
        struct.pack_into("<I", vbuf, off + 0x58, format_val)
        struct.pack_into("<BBBB", vbuf, off + 0x5C, 0, e.mip_count, 0, 0)
        struct.pack_into("<QQ", vbuf, off + 0x60, 0, 0)
        struct.pack_into("<Q", vbuf, off + 0x70, data_paddr)
        struct.pack_into("<Qqq", vbuf, off + 0x78, 0, 0, 0)

    for i, name_data in enumerate(name_bytes_list):
        start = name_offsets[i]
        vbuf[start:start + len(name_data)] = name_data

    vbuf[pagemap_offset] = 1
    vbuf[pagemap_offset + 1] = 1

    pbuf = bytearray()
    for e in entries:
        pbuf.extend(e.data)

    return build_rsc7(bytes(vbuf), bytes(pbuf))


def _parse_gtav(file_data: bytes) -> ITD:
    virtual_data, physical_data = decompress_rsc7(file_data)

    count = r_u16(virtual_data, 0x28)
    items_off = v2o(r_u64(virtual_data, 0x30))

    td = ITD(game=Game.GTA5)

    for i in range(count):
        tex_off = v2o(r_u64(virtual_data, items_off + 8 * i))

        name = _read_name(virtual_data, r_u64(virtual_data, tex_off + 0x28))
        width = r_i16(virtual_data, tex_off + 0x50)
        height = r_i16(virtual_data, tex_off + 0x52)
        format_val = r_u32(virtual_data, tex_off + 0x58)
        mip_levels = r_u8(virtual_data, tex_off + 0x5D)
        data_ptr = r_u64(virtual_data, tex_off + 0x70)

        fmt = _resolve_gtav_format(format_val)
        if fmt is None:
            raise ValueError(f"Unsupported texture format: 0x{format_val:08X}")

        phys_off = p2o(data_ptr)
        data_size = total_mip_data_size(width, height, fmt, mip_levels)
        pixel_data = _slice_texture_data(
            physical_data, phys_off, data_size, name=name,
            width=width, height=height, mip_levels=mip_levels,
        )
        offsets, sizes = _build_mip_info(width, height, fmt, mip_levels)

        td.add(Texture.from_raw(pixel_data, width, height, fmt,
                                 mip_levels, offsets, sizes, name))

    return td


def _inspect_gtav(file_data: bytes) -> list[dict]:
    virtual_data, _ = decompress_rsc7(file_data)

    count = r_u16(virtual_data, 0x28)
    items_off = v2o(r_u64(virtual_data, 0x30))

    result = []
    for i in range(count):
        tex_off = v2o(r_u64(virtual_data, items_off + 8 * i))

        name = _read_name(virtual_data, r_u64(virtual_data, tex_off + 0x28))
        width = r_i16(virtual_data, tex_off + 0x50)
        height = r_i16(virtual_data, tex_off + 0x52)
        format_val = r_u32(virtual_data, tex_off + 0x58)
        mip_levels = r_u8(virtual_data, tex_off + 0x5D)

        fmt = _resolve_gtav_format(format_val)
        data_size = total_mip_data_size(width, height, fmt, mip_levels) if fmt is not None else 0

        result.append({
            "name": name, "width": width, "height": height,
            "format": fmt,
            "format_name": fmt.name if fmt is not None else f"unknown(0x{format_val:08X})",
            "mip_count": mip_levels, "data_size": data_size,
        })

    return result


# ═════════════════════════════════════════════════════════════════════════════
# RDR2 (RSC8) internals
# ═════════════════════════════════════════════════════════════════════════════

_RDR2_TEX_SIZE = 0xB0  # 176 bytes

_RDR2_DICT_VFT      = 0x00000001409100B0
_RDR2_TEX_VFT       = 0x00000001409100B0
_RDR2_SRV_VFT       = 0x0000000140910080
_RDR2_FLAGS          = 0x18008002
_RDR2_TILE_STANDARD  = 13
_RDR2_DIM_2D         = 1
_RDR2_SRV_DIM_2D     = 0x0401


def _build_rdr2(textures: list[Texture], compression: RscCompression = RscCompression.OODLE) -> bytes:
    entries = sorted(textures, key=lambda t: joaat(t.name))
    n = len(entries)
    if n == 0:
        raise ValueError("Cannot create texture dictionary with zero textures")

    # Virtual layout
    dict_size = 64
    blockmap_off = align(dict_size, 16)
    blockmap_size = 16 + 2 * 8  # 1 virtual + 1 physical page

    hash_off = align(blockmap_off + blockmap_size, 16)
    ptr_off = align(hash_off + n * 4, 16)
    tex_off_base = align(ptr_off + n * 8, 16)

    cur = align(tex_off_base + _RDR2_TEX_SIZE * n, 16)
    name_offsets: list[int] = []
    name_bytes_list: list[bytes] = []
    for e in entries:
        name_offsets.append(cur)
        encoded = e.name.encode("utf-8") + b"\x00"
        name_bytes_list.append(encoded)
        cur = align(cur + len(encoded), 16)

    virtual_size = cur

    # Physical layout (padded to BlockCount * BlockStride)
    phys_offsets: list[int] = []
    phys_data_list: list[bytes] = []
    phys_cur = 0
    for e in entries:
        phys_offsets.append(phys_cur)
        bc = _block_count(e.format, e.width, e.height, 1, e.mip_count)
        target = bc * _block_stride(e.format)
        data = e.data if len(e.data) >= target else e.data + b"\x00" * (target - len(e.data))
        phys_data_list.append(data)
        phys_cur = align(phys_cur + len(data), 16)

    physical_size = phys_cur

    # Page sizes for BlockMap
    v_page = align(virtual_size, 0x10000 if virtual_size > 0x8000 else 16)
    p_page = align(physical_size, 0x10000 if physical_size > 0x8000 else 16)

    # Build virtual buffer
    vbuf = bytearray(virtual_size)

    # Dictionary root (64 bytes)
    struct.pack_into("<Q", vbuf, 0x00, _RDR2_DICT_VFT)
    struct.pack_into("<Q", vbuf, 0x08, DAT_VIRTUAL_BASE + blockmap_off)
    struct.pack_into("<Q", vbuf, 0x10, 0)
    struct.pack_into("<Q", vbuf, 0x18, 1)
    struct.pack_into("<Q", vbuf, 0x20, DAT_VIRTUAL_BASE + hash_off)
    struct.pack_into("<HHI", vbuf, 0x28, n, n, 0)
    struct.pack_into("<Q", vbuf, 0x30, DAT_VIRTUAL_BASE + ptr_off)
    struct.pack_into("<HHI", vbuf, 0x38, n, n, 0)

    # BlockMap
    struct.pack_into("<QBBHI", vbuf, blockmap_off, 0, 1, 1, 0, 0)
    struct.pack_into("<QQ", vbuf, blockmap_off + 16, v_page, p_page)

    # Hash array
    for i, e in enumerate(entries):
        struct.pack_into("<I", vbuf, hash_off + 4 * i, joaat(e.name))

    # Pointer array
    for i in range(n):
        struct.pack_into("<Q", vbuf, ptr_off + 8 * i,
                         DAT_VIRTUAL_BASE + tex_off_base + _RDR2_TEX_SIZE * i)

    # Texture blocks (176 bytes each)
    for i, e in enumerate(entries):
        off = tex_off_base + _RDR2_TEX_SIZE * i
        bc = _block_count(e.format, e.width, e.height, 1, e.mip_count)
        bs = _block_stride(e.format)

        # TextureBase (0x00–0x4F)
        struct.pack_into("<Q", vbuf, off + 0x00, _RDR2_TEX_VFT)
        struct.pack_into("<II", vbuf, off + 0x08, bc, bs)
        struct.pack_into("<II", vbuf, off + 0x10, _RDR2_FLAGS, 0)
        struct.pack_into("<HHH", vbuf, off + 0x18, e.width, e.height, 1)
        vbuf[off + 0x1E] = _RDR2_DIM_2D
        vbuf[off + 0x1F] = BC_TO_RSC8[e.format]
        vbuf[off + 0x20] = _RDR2_TILE_STANDARD
        vbuf[off + 0x21] = 0
        vbuf[off + 0x22] = e.mip_count
        struct.pack_into("<BBBH", vbuf, off + 0x23, 0, 0, 0, 1)  # unknowns + usage
        struct.pack_into("<Q", vbuf, off + 0x28, DAT_VIRTUAL_BASE + name_offsets[i])
        struct.pack_into("<Q", vbuf, off + 0x30, DAT_VIRTUAL_BASE + off + 0x68)  # SRV
        struct.pack_into("<Q", vbuf, off + 0x38, DAT_PHYSICAL_BASE + phys_offsets[i])
        struct.pack_into("<IIQ", vbuf, off + 0x40, 0, 0, 0)

        # Extended (0x50–0x67)
        struct.pack_into("<QQQ", vbuf, off + 0x50, 0, 0, 0)

        # Embedded SRV (0x68–0xA7)
        struct.pack_into("<QQ", vbuf, off + 0x68, _RDR2_SRV_VFT, 0)
        struct.pack_into("<QQ", vbuf, off + 0x78, _RDR2_SRV_DIM_2D, 5)
        struct.pack_into("<QQQQ", vbuf, off + 0x88, 0, 0, 0, 0)

        # Unknown_A8h
        struct.pack_into("<Q", vbuf, off + 0xA8, 0)

    # Name strings
    for i, name_data in enumerate(name_bytes_list):
        start = name_offsets[i]
        vbuf[start:start + len(name_data)] = name_data

    # Physical buffer
    pbuf = bytearray(physical_size)
    for i, data in enumerate(phys_data_list):
        pbuf[phys_offsets[i]:phys_offsets[i] + len(data)] = data

    return build_rsc8(bytes(vbuf), bytes(pbuf), compression=compression)


def _parse_rdr2(file_data: bytes) -> ITD:
    virtual_data, physical_data = decompress_rsc8(file_data)

    count = r_u16(virtual_data, 0x28)
    items_off = v2o(r_u64(virtual_data, 0x30))

    td = ITD(game=Game.RDR2)

    for i in range(count):
        tex_off = v2o(r_u64(virtual_data, items_off + 8 * i))

        name = _read_name(virtual_data, r_u64(virtual_data, tex_off + 0x28))
        width = r_u16(virtual_data, tex_off + 0x18)
        height = r_u16(virtual_data, tex_off + 0x1A)
        format_byte = r_u8(virtual_data, tex_off + 0x1F)
        mip_levels = r_u8(virtual_data, tex_off + 0x22)
        data_ptr = r_u64(virtual_data, tex_off + 0x38)

        fmt = RSC8_TO_BC.get(format_byte)
        if fmt is None:
            raise ValueError(f"Unsupported RSC8 format 0x{format_byte:02X} in '{name}'")

        phys_off = p2o(data_ptr)
        data_size = total_mip_data_size(width, height, fmt, mip_levels)
        pixel_data = _slice_texture_data(
            physical_data, phys_off, data_size, name=name,
            width=width, height=height, mip_levels=mip_levels,
        )
        offsets, sizes = _build_mip_info(width, height, fmt, mip_levels)

        td.add(Texture.from_raw(pixel_data, width, height, fmt,
                                 mip_levels, offsets, sizes, name))

    return td


def _inspect_rdr2(file_data: bytes) -> list[dict]:
    virtual_data, _ = decompress_rsc8(file_data)

    count = r_u16(virtual_data, 0x28)
    items_off = v2o(r_u64(virtual_data, 0x30))

    result = []
    for i in range(count):
        tex_off = v2o(r_u64(virtual_data, items_off + 8 * i))

        name = _read_name(virtual_data, r_u64(virtual_data, tex_off + 0x28))
        width = r_u16(virtual_data, tex_off + 0x18)
        height = r_u16(virtual_data, tex_off + 0x1A)
        format_byte = r_u8(virtual_data, tex_off + 0x1F)
        mip_levels = r_u8(virtual_data, tex_off + 0x22)

        fmt = RSC8_TO_BC.get(format_byte)
        data_size = total_mip_data_size(width, height, fmt, mip_levels) if fmt is not None else 0

        result.append({
            "name": name, "width": width, "height": height,
            "format": fmt,
            "format_name": fmt.name if fmt is not None else f"unknown(0x{format_byte:02X})",
            "mip_count": mip_levels, "data_size": data_size,
        })

    return result


# ═════════════════════════════════════════════════════════════════════════════
# GTA V Enhanced / gen9 (RSC7 version 5) internals
# ═════════════════════════════════════════════════════════════════════════════

_ENHANCED_TEX_SIZE   = 0x80  # 128 bytes
_ENHANCED_FLAGS      = 0x00260208
_ENHANCED_TILE_AUTO  = 255
_ENHANCED_UNK_23H    = 0x28
_ENHANCED_UNK_44H    = 2
_ENHANCED_DIM_2D     = 1
_ENHANCED_SRV_VFT    = 0x00000001406B77D8
_ENHANCED_SRV_DIM_2D = 0x41
_RSC7_VERSION_GEN9   = 5


def _build_enhanced(textures: list[Texture]) -> bytes:
    entries = sorted(textures, key=lambda t: joaat(t.name))
    n = len(entries)
    if n == 0:
        raise ValueError("Cannot create texture dictionary with zero textures")

    # Virtual layout (same dictionary header as legacy)
    dict_size = 0x40
    keys_offset = dict_size
    ptrs_offset = align(keys_offset + 4 * n, 16)
    textures_offset = align(ptrs_offset + 8 * n, 16)

    cur = textures_offset + _ENHANCED_TEX_SIZE * n
    name_offsets: list[int] = []
    name_bytes_list: list[bytes] = []
    for e in entries:
        name_offsets.append(cur)
        encoded = e.name.encode("utf-8") + b"\x00"
        name_bytes_list.append(encoded)
        cur += len(encoded)

    pagemap_offset = align(cur, 16)
    virtual_size = pagemap_offset + 0x10

    # Physical layout — gen9 uses align=1 (no block padding)
    phys_offsets: list[int] = []
    phys_data_list: list[bytes] = []
    phys_cur = 0
    for e in entries:
        phys_offsets.append(phys_cur)
        bc = _block_count(e.format, e.width, e.height, 1, e.mip_count, align=1)
        target = bc * _block_stride(e.format)
        data = e.data if len(e.data) >= target else e.data + b"\x00" * (target - len(e.data))
        phys_data_list.append(data)
        phys_cur = align(phys_cur + len(data), 16)

    physical_size = phys_cur

    # Build virtual buffer
    vbuf = bytearray(virtual_size)

    # Dictionary root (64 bytes)
    struct.pack_into("<Q", vbuf, 0x00, 0)  # VFT = 0
    struct.pack_into("<Q", vbuf, 0x08, DAT_VIRTUAL_BASE + pagemap_offset)
    struct.pack_into("<Q", vbuf, 0x10, 0)
    struct.pack_into("<I", vbuf, 0x18, 1)
    struct.pack_into("<I", vbuf, 0x1C, 0)
    struct.pack_into("<Q", vbuf, 0x20, DAT_VIRTUAL_BASE + keys_offset)
    struct.pack_into("<HHI", vbuf, 0x28, n, n, 0)
    struct.pack_into("<Q", vbuf, 0x30, DAT_VIRTUAL_BASE + ptrs_offset)
    struct.pack_into("<HHI", vbuf, 0x38, n, n, 0)

    # Hash array
    for i, e in enumerate(entries):
        struct.pack_into("<I", vbuf, keys_offset + 4 * i, joaat(e.name))

    # Pointer array
    for i in range(n):
        tex_vaddr = DAT_VIRTUAL_BASE + textures_offset + _ENHANCED_TEX_SIZE * i
        struct.pack_into("<Q", vbuf, ptrs_offset + 8 * i, tex_vaddr)

    # Texture blocks (128 bytes each)
    for i, e in enumerate(entries):
        off = textures_offset + _ENHANCED_TEX_SIZE * i
        bc = _block_count(e.format, e.width, e.height, 1, e.mip_count, align=1)
        bs = _block_stride(e.format)

        # TextureBase (0x00–0x4F)
        struct.pack_into("<II", vbuf, off + 0x00, 0, 1)         # VFT=0, Unknown_4h=1
        struct.pack_into("<II", vbuf, off + 0x08, bc, bs)        # BlockCount, BlockStride
        struct.pack_into("<II", vbuf, off + 0x10, _ENHANCED_FLAGS, 0)
        struct.pack_into("<HHH", vbuf, off + 0x18, e.width, e.height, 1)  # W, H, Depth
        vbuf[off + 0x1E] = _ENHANCED_DIM_2D
        vbuf[off + 0x1F] = BC_TO_RSC8[e.format]                 # DXGI format byte
        vbuf[off + 0x20] = _ENHANCED_TILE_AUTO                  # TileMode = Auto (255)
        vbuf[off + 0x21] = 0                                    # AntiAliasType
        vbuf[off + 0x22] = e.mip_count
        vbuf[off + 0x23] = _ENHANCED_UNK_23H
        vbuf[off + 0x24] = 0
        vbuf[off + 0x25] = 0
        struct.pack_into("<H", vbuf, off + 0x26, 1)             # UsageCount
        struct.pack_into("<Q", vbuf, off + 0x28, DAT_VIRTUAL_BASE + name_offsets[i])
        struct.pack_into("<Q", vbuf, off + 0x30, DAT_VIRTUAL_BASE + off + 0x58)  # SRV ptr
        struct.pack_into("<Q", vbuf, off + 0x38, DAT_PHYSICAL_BASE + phys_offsets[i])
        struct.pack_into("<II", vbuf, off + 0x40, 0, _ENHANCED_UNK_44H)
        struct.pack_into("<Q", vbuf, off + 0x48, 0)

        # Texture extra (0x50–0x7F)
        struct.pack_into("<Q", vbuf, off + 0x50, 0)
        # Embedded ShaderResourceView (32 bytes at 0x58)
        struct.pack_into("<Q", vbuf, off + 0x58, _ENHANCED_SRV_VFT)
        struct.pack_into("<Q", vbuf, off + 0x60, 0)
        struct.pack_into("<HHI", vbuf, off + 0x68, _ENHANCED_SRV_DIM_2D, 0xFFFF, 0xFFFFFFFF)
        struct.pack_into("<Q", vbuf, off + 0x70, 0)
        struct.pack_into("<Q", vbuf, off + 0x78, 0)

    # Name strings
    for i, name_data in enumerate(name_bytes_list):
        start = name_offsets[i]
        vbuf[start:start + len(name_data)] = name_data

    # Pagemap (same as legacy)
    vbuf[pagemap_offset] = 1
    vbuf[pagemap_offset + 1] = 1

    # Physical buffer
    pbuf = bytearray(physical_size)
    for i, data in enumerate(phys_data_list):
        pbuf[phys_offsets[i]:phys_offsets[i] + len(data)] = data

    return build_rsc7(bytes(vbuf), bytes(pbuf), version=_RSC7_VERSION_GEN9)


def _parse_enhanced(file_data: bytes) -> ITD:
    virtual_data, physical_data = decompress_rsc7(file_data)

    count = r_u16(virtual_data, 0x28)
    items_off = v2o(r_u64(virtual_data, 0x30))

    td = ITD(game=Game.GTA5_GEN9)

    for i in range(count):
        tex_off = v2o(r_u64(virtual_data, items_off + 8 * i))

        # Same field offsets as RDR2 texture base
        name = _read_name(virtual_data, r_u64(virtual_data, tex_off + 0x28))
        width = r_u16(virtual_data, tex_off + 0x18)
        height = r_u16(virtual_data, tex_off + 0x1A)
        format_byte = r_u8(virtual_data, tex_off + 0x1F)
        mip_levels = r_u8(virtual_data, tex_off + 0x22)
        data_ptr = r_u64(virtual_data, tex_off + 0x38)

        fmt = RSC8_TO_BC.get(format_byte)
        if fmt is None:
            raise ValueError(f"Unsupported gen9 format 0x{format_byte:02X} in '{name}'")

        phys_off = p2o(data_ptr)
        data_size = total_mip_data_size(width, height, fmt, mip_levels)
        pixel_data = _slice_texture_data(
            physical_data, phys_off, data_size, name=name,
            width=width, height=height, mip_levels=mip_levels,
        )
        offsets, sizes = _build_mip_info(width, height, fmt, mip_levels)

        td.add(Texture.from_raw(pixel_data, width, height, fmt,
                                 mip_levels, offsets, sizes, name))

    return td


def _inspect_enhanced(file_data: bytes) -> list[dict]:
    virtual_data, _ = decompress_rsc7(file_data)

    count = r_u16(virtual_data, 0x28)
    items_off = v2o(r_u64(virtual_data, 0x30))

    result = []
    for i in range(count):
        tex_off = v2o(r_u64(virtual_data, items_off + 8 * i))

        name = _read_name(virtual_data, r_u64(virtual_data, tex_off + 0x28))
        width = r_u16(virtual_data, tex_off + 0x18)
        height = r_u16(virtual_data, tex_off + 0x1A)
        format_byte = r_u8(virtual_data, tex_off + 0x1F)
        mip_levels = r_u8(virtual_data, tex_off + 0x22)

        fmt = RSC8_TO_BC.get(format_byte)
        data_size = total_mip_data_size(width, height, fmt, mip_levels) if fmt is not None else 0

        result.append({
            "name": name, "width": width, "height": height,
            "format": fmt,
            "format_name": fmt.name if fmt is not None else f"unknown(0x{format_byte:02X})",
            "mip_count": mip_levels, "data_size": data_size,
        })

    return result


# ═════════════════════════════════════════════════════════════════════════════
# GTA IV (RSC5) internals — 32-bit pointers, .wtd files
# ═════════════════════════════════════════════════════════════════════════════

_GTA4_TEX_SIZE = 80      # bytes per texture struct
_GTA4_DICT_SIZE = 32     # bytes for dictionary header
_GTA4_BLOCKMAP_SIZE = 528  # 16 + 128 * 4

_V32 = 0x50000000
_P32 = 0x60000000


def v2o32(addr: int) -> int:
    return addr - _V32


def p2o32(addr: int) -> int:
    return addr - _P32


def _read_name_gta4(virtual_data: bytes, name_ptr: int) -> str:
    """Read a GTA4 name string (format: 'pack:/{name}.dds')."""
    off = v2o32(name_ptr)
    end = virtual_data.index(b"\x00", off)
    raw = virtual_data[off:end].decode("utf-8", errors="replace")
    name = raw
    if name.startswith("pack:/"):
        name = name[6:]
    if name.endswith(".dds"):
        name = name[:-4]
    return name


def _build_gta4(textures: list[Texture]) -> bytes:
    entries = sorted(textures, key=lambda t: joaat(t.name))
    n = len(entries)
    if n == 0:
        raise ValueError("Cannot create texture dictionary with zero textures")

    for e in entries:
        if e.format in _GTA4_UNSUPPORTED:
            raise ValueError(
                f"Format {e.format.name} is not supported by GTA IV. "
                f"Use BC1, BC3, or A8R8G8B8."
            )

    # Virtual layout — all 32-bit pointers
    blockmap_off = _GTA4_DICT_SIZE
    hash_off = align(blockmap_off + _GTA4_BLOCKMAP_SIZE, 16)
    ptr_off = align(hash_off + n * 4, 16)
    tex_off_base = align(ptr_off + n * 4, 16)

    cur = tex_off_base + _GTA4_TEX_SIZE * n
    name_offsets: list[int] = []
    name_bytes_list: list[bytes] = []
    for e in entries:
        name_offsets.append(cur)
        encoded = f"pack:/{e.name}.dds".encode("utf-8") + b"\x00"
        name_bytes_list.append(encoded)
        cur += len(encoded)

    virtual_size = align(cur, 16)

    # Physical layout
    phys_offsets: list[int] = []
    phys_cur = 0
    for e in entries:
        phys_offsets.append(phys_cur)
        phys_cur += len(e.data)

    # Build virtual buffer
    vbuf = bytearray(virtual_size)

    # Dictionary (32 bytes)
    struct.pack_into("<I", vbuf, 0x00, 0)                    # VFT
    struct.pack_into("<I", vbuf, 0x04, _V32 + blockmap_off)  # BlockMap ptr
    struct.pack_into("<I", vbuf, 0x08, 0)                    # ParentDictionary
    struct.pack_into("<I", vbuf, 0x0C, 1)                    # UsageCount
    struct.pack_into("<I", vbuf, 0x10, _V32 + hash_off)      # Hash array ptr
    struct.pack_into("<HH", vbuf, 0x14, n, n)                # count, capacity
    struct.pack_into("<I", vbuf, 0x18, _V32 + ptr_off)       # Textures ptr array ptr
    struct.pack_into("<HH", vbuf, 0x1C, n, n)                # count, capacity

    # BlockMap (528 bytes = 16 header + 128 * 4 padding)
    struct.pack_into("<I", vbuf, blockmap_off + 0x00, 0)
    for bm_i in range(1, 132):  # entries 1-131 = 0xCDCDCDCD
        struct.pack_into("<I", vbuf, blockmap_off + bm_i * 4, 0xCDCDCDCD)

    # Hash array
    for i, e in enumerate(entries):
        struct.pack_into("<I", vbuf, hash_off + 4 * i, joaat(e.name))

    # Pointer array (uint32)
    for i in range(n):
        struct.pack_into("<I", vbuf, ptr_off + 4 * i,
                         _V32 + tex_off_base + _GTA4_TEX_SIZE * i)

    # Texture blocks (80 bytes each)
    for i, e in enumerate(entries):
        off = tex_off_base + _GTA4_TEX_SIZE * i
        format_val = BC_TO_RSC5[e.format]
        # Stride = width * bits_per_pixel / 8
        bpp = {
            BCFormat.BC1: 4,
            BCFormat.BC1A: 4,
            BCFormat.BC3: 8,
            BCFormat.A8R8G8B8: 32,
        }[e.format]
        stride = e.width * bpp // 8

        # TextureBase (28 bytes)
        struct.pack_into("<II", vbuf, off + 0x00, 0, 0)       # VFT, Unknown1
        struct.pack_into("<HH", vbuf, off + 0x08, 1, 0)       # Unknown2=1, Unknown3=0
        struct.pack_into("<II", vbuf, off + 0x0C, 0, 0)       # Unknown4, Unknown5
        struct.pack_into("<I", vbuf, off + 0x14, _V32 + name_offsets[i])
        struct.pack_into("<I", vbuf, off + 0x18, 0)           # Unknown6

        # Texture-specific (52 bytes)
        struct.pack_into("<HH", vbuf, off + 0x1C, e.width, e.height)
        struct.pack_into("<I", vbuf, off + 0x20, format_val)
        struct.pack_into("<H", vbuf, off + 0x24, stride)
        vbuf[off + 0x26] = 0                                   # TextureType
        vbuf[off + 0x27] = e.mip_count
        struct.pack_into("<ffffff", vbuf, off + 0x28,
                         1.0, 1.0, 1.0, 0.0, 0.0, 0.0)       # Unknown7–12
        struct.pack_into("<II", vbuf, off + 0x40, 0, 0)       # Prev/Next
        struct.pack_into("<I", vbuf, off + 0x48, _P32 + phys_offsets[i])
        struct.pack_into("<I", vbuf, off + 0x4C, 0)           # Unknown13

    # Name strings
    for i, name_data in enumerate(name_bytes_list):
        start = name_offsets[i]
        vbuf[start:start + len(name_data)] = name_data

    # Physical buffer
    pbuf = bytearray()
    for e in entries:
        pbuf.extend(e.data)

    return build_rsc5(bytes(vbuf), bytes(pbuf))


def _parse_gta4(file_data: bytes) -> ITD:
    virtual_data, physical_data = decompress_rsc5(file_data)

    count = r_u16(virtual_data, 0x14)
    ptr_arr_off = v2o32(r_u32(virtual_data, 0x18))

    td = ITD(game=Game.GTA4)

    for i in range(count):
        tex_off = v2o32(r_u32(virtual_data, ptr_arr_off + 4 * i))

        name = _read_name_gta4(virtual_data, r_u32(virtual_data, tex_off + 0x14))
        width = r_u16(virtual_data, tex_off + 0x1C)
        height = r_u16(virtual_data, tex_off + 0x1E)
        format_val = r_u32(virtual_data, tex_off + 0x20)
        mip_levels = virtual_data[tex_off + 0x27]
        data_ptr = r_u32(virtual_data, tex_off + 0x48)

        fmt = RSC5_TO_BC.get(format_val)
        if fmt is None:
            raise ValueError(f"Unsupported RSC5 format 0x{format_val:08X} in '{name}'")

        phys_off = p2o32(data_ptr)
        data_size = total_mip_data_size(width, height, fmt, mip_levels)
        pixel_data = _slice_texture_data(
            physical_data, phys_off, data_size, name=name,
            width=width, height=height, mip_levels=mip_levels,
        )
        offsets, sizes = _build_mip_info(width, height, fmt, mip_levels)

        td.add(Texture.from_raw(pixel_data, width, height, fmt,
                                 mip_levels, offsets, sizes, name))

    return td


def _inspect_gta4(file_data: bytes) -> list[dict]:
    virtual_data, _ = decompress_rsc5(file_data)

    count = r_u16(virtual_data, 0x14)
    ptr_arr_off = v2o32(r_u32(virtual_data, 0x18))

    result = []
    for i in range(count):
        tex_off = v2o32(r_u32(virtual_data, ptr_arr_off + 4 * i))

        name = _read_name_gta4(virtual_data, r_u32(virtual_data, tex_off + 0x14))
        width = r_u16(virtual_data, tex_off + 0x1C)
        height = r_u16(virtual_data, tex_off + 0x1E)
        format_val = r_u32(virtual_data, tex_off + 0x20)
        mip_levels = virtual_data[tex_off + 0x27]

        fmt = RSC5_TO_BC.get(format_val)
        data_size = total_mip_data_size(width, height, fmt, mip_levels) if fmt is not None else 0

        result.append({
            "name": name, "width": width, "height": height,
            "format": fmt,
            "format_name": fmt.name if fmt is not None else f"unknown(0x{format_val:08X})",
            "mip_count": mip_levels, "data_size": data_size,
        })

    return result
