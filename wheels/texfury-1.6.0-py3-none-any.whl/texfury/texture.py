"""Texture class — the core unit of texfury."""

from __future__ import annotations

import logging
from pathlib import Path

log = logging.getLogger("texfury")

from texfury import _native as native
from texfury.formats import (
    BCFormat, MipFilter, is_block_compressed,
)

# Try importing Pillow (optional)
try:
    from PIL import Image as PILImage
    _HAS_PIL = True
except ImportError:
    _HAS_PIL = False


class Texture:
    """A compressed DDS texture with optional mipmaps.

    Create via class methods:
        Texture.from_image("photo.png")
        Texture.from_dds("existing.dds")
        Texture.from_pil(pil_image)
    """

    __slots__ = ("_data", "_width", "_height", "_format", "_mip_count",
                 "_mip_offsets", "_mip_sizes", "_name", "_has_transparency")

    def __init__(self, data: bytes, width: int, height: int,
                 fmt: BCFormat, mip_count: int,
                 mip_offsets: list[int], mip_sizes: list[int],
                 name: str = "", has_transparency: bool | None = None):
        self._data = data
        self._width = width
        self._height = height
        self._format = fmt
        self._mip_count = mip_count
        self._mip_offsets = mip_offsets
        self._mip_sizes = mip_sizes
        self._name = name
        self._has_transparency = has_transparency

    # ── Properties ────────────────────────────────────────────────────────

    @property
    def data(self) -> bytes:
        return self._data

    @property
    def width(self) -> int:
        return self._width

    @property
    def height(self) -> int:
        return self._height

    @property
    def format(self) -> BCFormat:
        return self._format

    @property
    def mip_count(self) -> int:
        return self._mip_count

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        self._name = value

    @property
    def is_power_of_two(self) -> bool:
        """True if both dimensions are powers of two."""
        w, h = self._width, self._height
        return w > 0 and h > 0 and (w & (w - 1)) == 0 and (h & (h - 1)) == 0

    @property
    def has_alpha_format(self) -> bool:
        """True if the compression format supports an alpha channel."""
        return self._format in (
            BCFormat.BC1A, BCFormat.BC2, BCFormat.BC3, BCFormat.BC7,
            BCFormat.A8R8G8B8, BCFormat.R8G8B8A8, BCFormat.A8,
            BCFormat.B5G5R5A1, BCFormat.R10G10B10A2,
            BCFormat.R16G16B16A16_FLOAT, BCFormat.R32G32B32A32_FLOAT,
        )

    def has_transparency(self) -> bool:
        """Check if the texture has any non-opaque pixels.

        When created via ``from_image``/``from_bytes``/``from_pil``, this
        is detected from the original uncompressed pixels (free).
        Otherwise falls back to decompressing mip 0 (slower).
        """
        if self._has_transparency is not None:
            return self._has_transparency
        rgba, w, h = self.to_rgba(0)
        alpha = rgba[3::4]
        result = alpha.count(255) != len(alpha)
        self._has_transparency = result
        return result

    @property
    def pot_dimensions(self) -> tuple[int, int]:
        """Nearest power-of-two dimensions for this texture."""
        return (native.nearest_power_of_two(self._width),
                native.nearest_power_of_two(self._height))

    @property
    def is_block_compressed(self) -> bool:
        """True if the format uses block compression (BC1-BC7)."""
        return is_block_compressed(self._format)

    # ── Factory methods ───────────────────────────────────────────────────

    @classmethod
    def from_image(cls, source: str | Path, *,
                   format: BCFormat = BCFormat.BC1,
                   quality: float = 0.7,
                   generate_mipmaps: bool = True,
                   min_mip_size: int = 4,
                   resize_to_pot: bool = True,
                   mip_filter: MipFilter = MipFilter.MITCHELL,
                   name: str = "") -> Texture:
        """Load an image file and compress it.

        Parameters
        ----------
        source : path
            Image file (PNG, JPG, TGA, BMP, PSD, WebP, etc.)
        format : BCFormat
            Target compression format.
        quality : float
            Compression quality 0.0 (fastest) to 1.0 (best).
        generate_mipmaps : bool
            Generate mipmap chain.
        min_mip_size : int
            Minimum dimension for smallest mip level.
        resize_to_pot : bool
            Resize to nearest power-of-two if needed.
        mip_filter : MipFilter
            Downsampling filter for mipmap generation and POT resize.
        name : str
            Texture name (defaults to filename stem).
        """
        path = Path(source)
        if not name:
            name = path.stem.lower()

        # Try native loader first (stb_image: PNG, JPG, TGA, BMP, PSD, WebP, etc.)
        # If it fails, fall back to Pillow for formats stb doesn't support (TIFF, etc.)
        log.debug("from_image: %s → %s q=%.2f", name, format.name, quality)
        try:
            img = native.load_image(str(path.resolve()))
        except OSError:
            if not _HAS_PIL:
                raise
            log.debug("stb_image failed, falling back to Pillow")
            return cls.from_pil(PILImage.open(path), format=format,
                                quality=quality,
                                generate_mipmaps=generate_mipmaps,
                                min_mip_size=min_mip_size,
                                resize_to_pot=resize_to_pot,
                                mip_filter=mip_filter,
                                name=name)

        try:
            return cls._compress_image(img, format=format, quality=quality,
                                        generate_mipmaps=generate_mipmaps,
                                        min_mip_size=min_mip_size,
                                        resize_to_pot=resize_to_pot,
                                        mip_filter=mip_filter,
                                        name=name)
        finally:
            native.free_image(img)

    @classmethod
    def from_bytes(cls, data: bytes, *,
                   format: BCFormat = BCFormat.BC1,
                   quality: float = 0.7,
                   generate_mipmaps: bool = True,
                   min_mip_size: int = 4,
                   resize_to_pot: bool = True,
                   mip_filter: MipFilter = MipFilter.MITCHELL,
                   recompress: bool = False,
                   name: str = "") -> Texture:
        """Load an image or DDS from in-memory bytes.

        Accepts the raw file bytes of any image format supported by
        ``from_image`` (PNG, JPG, TGA, BMP, PSD, WebP, etc.) or DDS
        files.  DDS files are loaded as-is by default; set
        ``recompress=True`` to decompress and re-encode with the given
        format and quality.

        Parameters
        ----------
        data : bytes
            Raw file bytes (image or DDS).
        format : BCFormat
            Target compression format (ignored for DDS unless recompress=True).
        quality : float
            Compression quality 0.0 (fastest) to 1.0 (best).
        generate_mipmaps : bool
            Generate mipmap chain.
        min_mip_size : int
            Minimum dimension for smallest mip level.
        resize_to_pot : bool
            Resize to nearest power-of-two if needed.
        mip_filter : MipFilter
            Downsampling filter for mipmap generation and POT resize.
        recompress : bool
            If True and input is DDS, decompress and re-encode with the
            given format/quality. If False (default), DDS is loaded as-is.
        name : str
            Texture name.
        """
        # DDS detection: magic bytes "DDS " (0x20534444)
        log.debug("from_bytes: %d bytes, format=%s, recompress=%s", len(data), format.name, recompress)
        if len(data) >= 4 and data[:4] == b'DDS ':
            if not recompress:
                return cls.from_dds_bytes(data, name=name)
            # Recompress: load DDS → decompress to RGBA → compress
            tex = cls.from_dds_bytes(data, name=name)
            rgba, w, h = tex.to_rgba(0)
            img = native.create_image(w, h, rgba)
            try:
                return cls._compress_image(img, format=format, quality=quality,
                                            generate_mipmaps=generate_mipmaps,
                                            min_mip_size=min_mip_size,
                                            resize_to_pot=resize_to_pot,
                                            mip_filter=mip_filter,
                                            name=name or tex.name)
            finally:
                native.free_image(img)

        # Try native decoder first (stb_image)
        try:
            img = native.load_image_memory(data)
        except OSError:
            if not _HAS_PIL:
                raise
            import io
            return cls.from_pil(PILImage.open(io.BytesIO(data)),
                                format=format, quality=quality,
                                generate_mipmaps=generate_mipmaps,
                                min_mip_size=min_mip_size,
                                resize_to_pot=resize_to_pot,
                                mip_filter=mip_filter,
                                name=name)

        try:
            return cls._compress_image(img, format=format, quality=quality,
                                        generate_mipmaps=generate_mipmaps,
                                        min_mip_size=min_mip_size,
                                        resize_to_pot=resize_to_pot,
                                        mip_filter=mip_filter,
                                        name=name)
        finally:
            native.free_image(img)

    @classmethod
    def from_pil(cls, image, *,
                 format: BCFormat = BCFormat.BC1,
                 quality: float = 0.7,
                 generate_mipmaps: bool = True,
                 min_mip_size: int = 4,
                 resize_to_pot: bool = True,
                 mip_filter: MipFilter = MipFilter.MITCHELL,
                 name: str = "") -> Texture:
        """Create a Texture from a PIL/Pillow Image object.

        Requires Pillow to be installed.
        """
        if not _HAS_PIL:
            raise ImportError("Pillow is required for from_pil(). "
                              "Install it with: pip install Pillow")

        rgba = image.convert("RGBA")
        raw = rgba.tobytes()
        img = native.create_image(rgba.width, rgba.height, raw)
        try:
            return cls._compress_image(img, format=format, quality=quality,
                                        generate_mipmaps=generate_mipmaps,
                                        min_mip_size=min_mip_size,
                                        resize_to_pot=resize_to_pot,
                                        mip_filter=mip_filter,
                                        name=name)
        finally:
            native.free_image(img)

    @classmethod
    def from_dds(cls, source: str | Path, *, name: str = "") -> Texture:
        """Load an existing DDS file."""
        path = Path(source)
        if not name:
            name = path.stem.lower()

        c = native.load_dds(str(path.resolve()))
        try:
            return cls._from_compressed_handle(c, name)
        finally:
            native.free_compressed(c)

    @classmethod
    def from_dds_bytes(cls, data: bytes, *, name: str = "") -> Texture:
        """Load a DDS texture from in-memory bytes."""
        c = native.load_dds_memory(data)
        try:
            return cls._from_compressed_handle(c, name)
        finally:
            native.free_compressed(c)

    @staticmethod
    def inspect_dds(source: str | Path) -> dict:
        """Read DDS metadata without loading pixel data.

        Returns dict with keys: width, height, format, format_name, mip_count, data_size.
        """
        path = Path(source)
        c = native.load_dds(str(path.resolve()))
        try:
            fmt = BCFormat(native.compressed_format(c))
            return {
                "name": path.stem.lower(),
                "width": native.compressed_width(c),
                "height": native.compressed_height(c),
                "format": fmt,
                "format_name": fmt.name,
                "mip_count": native.compressed_mip_count(c),
                "data_size": native.compressed_size(c),
            }
        finally:
            native.free_compressed(c)

    @classmethod
    def from_raw(cls, data: bytes, width: int, height: int,
                 fmt: BCFormat, mip_count: int,
                 mip_offsets: list[int], mip_sizes: list[int],
                 name: str = "") -> Texture:
        """Create from raw compressed pixel data (for internal use)."""
        return cls(data, width, height, fmt, mip_count,
                   mip_offsets, mip_sizes, name)

    # ── Output ────────────────────────────────────────────────────────────

    def save_dds(self, path: str | Path) -> None:
        """Write this texture as a DDS file."""
        log.debug("save_dds: %s (%s %dx%d)", path, self._format.name, self._width, self._height)
        Path(path).write_bytes(self.to_dds_bytes())

    def to_dds_bytes(self) -> bytes:
        """Return complete DDS file as bytes."""
        c = self._to_compressed_handle()
        try:
            return native.save_dds_memory(c)
        finally:
            native.free_compressed(c)

    def to_rgba(self, mip: int = 0) -> tuple[bytes, int, int]:
        """Decompress to raw RGBA pixels.

        Returns (rgba_bytes, width, height) for the given mip level.
        """
        c = self._to_compressed_handle()
        try:
            return native.decompress(c, mip)
        finally:
            native.free_compressed(c)

    def to_pil(self, mip: int = 0):
        """Decompress to a Pillow Image. Requires Pillow.

        Returns a PIL.Image.Image in RGBA mode.
        """
        if not _HAS_PIL:
            raise ImportError("Pillow is required for to_pil(). "
                              "Install it with: pip install Pillow")
        rgba, w, h = self.to_rgba(mip)
        return PILImage.frombytes("RGBA", (w, h), rgba)

    def quality_metrics(self, original_rgba: bytes) -> dict:
        """Compare this texture against original RGBA pixels.

        Parameters
        ----------
        original_rgba : bytes
            Original uncompressed RGBA pixel data (same dimensions as mip 0).

        Returns
        -------
        dict with keys: psnr_rgb, psnr_rgba, ssim
        """
        decompressed, w, h = self.to_rgba(0)
        return {
            "psnr_rgb": native.psnr(original_rgba, decompressed, w, h, 3),
            "psnr_rgba": native.psnr(original_rgba, decompressed, w, h, 4),
            "ssim": native.ssim(original_rgba, decompressed, w, h),
        }

    def validate(self) -> list[str]:
        """Check texture for common issues.

        Returns a list of warning strings. Empty list means everything is OK.
        """
        warnings = []
        w, h = self._width, self._height

        if w <= 0 or h <= 0:
            warnings.append(f"Invalid dimensions: {w}x{h}")

        if w & (w - 1) != 0 or h & (h - 1) != 0:
            warnings.append(f"Non-power-of-two dimensions: {w}x{h}")

        if is_block_compressed(self._format):
            if w < 4 or h < 4:
                warnings.append(
                    f"Dimensions {w}x{h} below minimum 4x4 for "
                    f"{self._format.name}")

        if self._mip_count < 1:
            warnings.append("No mip levels")

        from texfury.formats import total_mip_data_size
        expected = total_mip_data_size(w, h, self._format, self._mip_count)
        actual = len(self._data)
        if actual != expected:
            warnings.append(
                f"Data size mismatch: expected {expected} bytes, "
                f"got {actual} bytes")

        if w > 16384 or h > 16384:
            warnings.append(f"Dimensions {w}x{h} exceed 16384 max")

        if not self._name:
            warnings.append("Texture has no name")

        return warnings

    # ── Transforms ────────────────────────────────────────────────────────

    def resize(self, width: int, height: int, *,
               quality: float = 0.7,
               generate_mipmaps: bool = True,
               min_mip_size: int = 4,
               mip_filter: MipFilter = MipFilter.MITCHELL) -> Texture:
        """Resize this texture to new dimensions.

        Decompresses, resizes, and recompresses with the same format.

        Parameters
        ----------
        width, height : int
            Target dimensions.
        quality : float
            Compression quality for recompression.
        generate_mipmaps : bool
            Regenerate mipmap chain after resize.
        min_mip_size : int
            Minimum dimension for smallest mip level.
        mip_filter : MipFilter
            Resampling filter.
        """
        rgba, rw, rh = self.to_rgba(0)
        img = native.create_image(rw, rh, rgba)
        try:
            resized = native.resize(img, width, height, int(mip_filter))
            try:
                tex = self._compress_image(
                    resized,
                    format=self._format,
                    quality=quality,
                    generate_mipmaps=generate_mipmaps,
                    min_mip_size=min_mip_size,
                    resize_to_pot=False,
                    mip_filter=mip_filter,
                    name=self._name,
                )
                log.debug("resize: %s %dx%d → %dx%d", self._name, rw, rh, width, height)
                return tex
            finally:
                native.free_image(resized)
        finally:
            native.free_image(img)

    def to_format(self, format: BCFormat, *,
                  quality: float = 0.7,
                  generate_mipmaps: bool = True,
                  min_mip_size: int = 4,
                  mip_filter: MipFilter = MipFilter.MITCHELL) -> Texture:
        """Recompress this texture to a different format.

        Decompresses to RGBA and recompresses with the new format.

        Parameters
        ----------
        format : BCFormat
            Target format.
        quality : float
            Compression quality.
        generate_mipmaps : bool
            Regenerate mipmap chain.
        min_mip_size : int
            Minimum dimension for smallest mip level.
        mip_filter : MipFilter
            Downsampling filter for mipmaps.
        """
        rgba, w, h = self.to_rgba(0)
        img = native.create_image(w, h, rgba)
        try:
            tex = self._compress_image(
                img,
                format=format,
                quality=quality,
                generate_mipmaps=generate_mipmaps,
                min_mip_size=min_mip_size,
                resize_to_pot=False,
                mip_filter=mip_filter,
                name=self._name,
            )
            log.debug("to_format: %s %s → %s", self._name, self._format.name, format.name)
            return tex
        finally:
            native.free_image(img)

    # ── Internal ──────────────────────────────────────────────────────────

    def _to_compressed_handle(self):
        """Build a native TfCompressed handle from this texture's data."""
        return native.create_compressed(
            self._data,
            self._width,
            self._height,
            int(self._format),
            self._mip_count,
            self._mip_offsets,
            self._mip_sizes,
        )

    @classmethod
    def _compress_image(cls, img, *, format: BCFormat, quality: float,
                        generate_mipmaps: bool, min_mip_size: int,
                        resize_to_pot: bool, mip_filter: MipFilter,
                        name: str) -> Texture:
        work_img = img
        resized = None

        if resize_to_pot and not native.is_power_of_two(
                native.image_width(img), native.image_height(img)):
            resized = native.resize_to_pot(img, int(mip_filter))
            work_img = resized

        try:
            transparent = native.has_transparency(work_img)
            c = native.compress(work_img, int(format), generate_mipmaps,
                                min_mip_size, quality, int(mip_filter))
            try:
                tex = cls._from_compressed_handle(c, name)
                tex._has_transparency = transparent and tex.has_alpha_format
                return tex
            finally:
                native.free_compressed(c)
        finally:
            if resized is not None:
                native.free_image(resized)

    @classmethod
    def _from_compressed_handle(cls, c, name: str) -> Texture:
        data = native.compressed_data(c)
        width = native.compressed_width(c)
        height = native.compressed_height(c)
        fmt = BCFormat(native.compressed_format(c))
        mip_count = native.compressed_mip_count(c)
        offsets = [native.compressed_mip_offset(c, i) for i in range(mip_count)]
        sizes = [native.compressed_mip_size(c, i) for i in range(mip_count)]
        return cls(data, width, height, fmt, mip_count, offsets, sizes, name)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Texture):
            return NotImplemented
        return (self._width == other._width
                and self._height == other._height
                and self._format == other._format
                and self._mip_count == other._mip_count
                and self._data == other._data)

    def __hash__(self) -> int:
        return hash((self._width, self._height, self._format,
                     self._mip_count, len(self._data)))

    def __repr__(self) -> str:
        return (f"Texture(name={self._name!r}, {self._width}x{self._height}, "
                f"format={self._format.name}, mips={self._mip_count})")
